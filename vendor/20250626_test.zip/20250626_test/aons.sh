#!/bin/sh

/mnt/SDCARD/ons/onscripter > /mnt/SDCARD/ons/a.txt 2>&1
